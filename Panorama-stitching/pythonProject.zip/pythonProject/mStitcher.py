import numpy as np
import cv2

class Stitcher:

    # 拼接函数
    #ratio reprojThresh改变影响拼接结果
    def stitch(self, images, ratio=0.75, reprojThresh=4.0):
        # 获取输入图片
        a = images[0]
        for b in images[1:]:
            imageA = a
            imageB = b
            # 检测A、B图片的SIFT关键特征点，并计算特征描述子
            (kpsA, ftreA) = self.detectAndDescribe(imageA)
            (kpsB, ftreB) = self.detectAndDescribe(imageB)

            # 匹配两张图片的所有特征点，返回匹配结果
            M = self.matchKeypoints(kpsA, kpsB, ftreA, ftreB, ratio, reprojThresh)

            # 如果返回结果为空，没有匹配成功的特征点，退出算法
            if M is None:
                return None

            # 否则，提取匹配结果
            # H是3x3视角变换矩阵
            (matches, H, status) = M

            #翘曲变换
            xh = np.linalg.inv(H)
            f1 = np.dot(xh, np.array([0, 0, 1]))
            f1 = f1 / f1[-1]
            xh[0][-1] += abs(f1[0])
            xh[1][-1] += abs(f1[1])  #
            ds = np.dot(xh, np.array([imageA.shape[1], imageA.shape[0], 1]))
            newy = abs(int(f1[1]))
            newx = abs(int(f1[0]))
            newsize = (int(ds[0]) + newx, int(ds[1]) + newy)
            tmp = cv2.warpPerspective(imageA,xh,newsize)

            #边缝融合
            tmp = self.seamEstimation(tmp,imageA,imageB,newx,newy)

            #result暴力拼接
            #result[offsety:imageB.shape[0]+offsety, offsetx:imageB.shape[1]+offsetx] = imageB

            #迭代下次拼接
            a = tmp
        return a

    def detectAndDescribe(self, img):
        # 将彩色图片转换成灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 建立SIFT生成器
        img_dscrptr = cv2.xfeatures2d.SIFT_create()
        # 检测SIFT特征点，并计算描述子
        (kps, ftre) = img_dscrptr.detectAndCompute(gray, None)
        # 将结果转换成numpy数组
        kps = np.float32([kp.pt for kp in kps])
        # 返回特征点集，及对应的描述特征
        return (kps, ftre)

    #建立匹配点
    def matchKeypoints(self, kpsA, kpsB, ftreA, ftreB, ratio, reprojThresh):
        # 建立暴力匹配器
        matcher = cv2.BFMatcher()
        # 使用KNN检测来自A、B图的SIFT特征匹配对，K=2
        rawMatches = matcher.knnMatch(ftreB, ftreA, 2)
        matches = []
        for m in rawMatches:
            # 当最近距离跟次近距离的比值小于ratio值时，保留此匹配对
            if len(m) == 2 and m[0].distance < m[1].distance * ratio:
                # 存储两个点在featuresA, featuresB中的索引值
                matches.append((m[0].trainIdx, m[0].queryIdx))
        # 当筛选后的匹配对大于4时，计算视角变换矩阵
        if len(matches) > 4:
            # 获取匹配对的点坐标
            ptsA = np.float32([kpsA[i] for (i, _) in matches])#左图找右图
            ptsB = np.float32([kpsB[i] for (_, i) in matches])#右找左
            # 计算视角变换矩阵
            #reprojThresh 为将点对视为内点的最大允许重投影错误阈值
            (H, status) = cv2.findHomography(ptsB, ptsA, cv2.RANSAC, reprojThresh)
            # 返回结果
            return (matches, H, status)
        return None

    #绘画匹配点对
    def drawMatches(self, imageA, imageB, kpsA, kpsB, matches, status):
        # 初始化可视化图片，将A、B图左右连接到一起
        (hA, wA) = imageA.shape[:2]
        (hB, wB) = imageB.shape[:2]
        vis = np.zeros((max(hA, hB), wA + wB, 3), dtype="uint8")
        vis[0:hA, 0:wA] = imageA
        vis[0:hB, wA:] = imageB

        # 联合遍历，画出匹配对
        for ((trainIdx, queryIdx), s) in zip(matches, status):
            # 当点对匹配成功时，画到可视化图上
            if s == 1:
                # 画出匹配对
                ptA = (int(kpsA[queryIdx][0]), int(kpsA[queryIdx][1]))
                ptB = (int(kpsB[trainIdx][0]) + wA, int(kpsB[trainIdx][1]))
                cv2.line(vis, ptA, ptB, (0, 255, 0), 1)

        # 返回可视化结果
        return vis

    #孔洞填充
    def fillHole(self, img):
        result = img.copy()
        h,w = img.shape[:2]
        mask = np.zeros((h+2,w+2),np.uint8)
        cv2.floodFill(result, mask,(0,0),255)
        img2 = cv2.bitwise_not(result)
        imout = img | img2
        return imout

    #裁剪黑边
    def Extra(self, img):
        img = cv2.copyMakeBorder(img, 10, 10, 10, 10, cv2.BORDER_CONSTANT, (0, 0, 0))
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY)
        #孔洞填充
        thresh = self.fillHole(thresh)

        cnts, hierarchy = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnt = max(cnts, key=cv2.contourArea)

        mask = np.zeros(thresh.shape, dtype="uint8")
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(mask, (x, y), (x + w, y + h), 255, -1)
        minRect = mask.copy()
        sub = mask.copy()
        # 开始while循环，直到sub中不再有前景像素
        while cv2.countNonZero(sub) > 0:
            minRect = cv2.erode(minRect, None)
            sub = cv2.subtract(minRect, thresh)

        cnts, hierarchy = cv2.findContours(minRect.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnt = max(cnts, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(cnt)

        # 使用边界框坐标提取最终的全景图
        img = img[y:y + h, x:x + w]
        return img

    #边缝融合
    def seamEstimation(self,tmp,leimg,riimg,newx,newy):
        alpha = 0.0
        processwidth = leimg.shape[1] - newx
        for x in range(newx,tmp.shape[1]):
            test_y = int((newy + leimg.shape[0])/2)
            if np.array_equal(tmp[test_y,x],np.array([0,0,0])):
                processwidth = x - newx
                break
        x_max = np.minimum(newx+riimg.shape[1],tmp.shape[1])
        y_max = np.minimum(newy+riimg.shape[0],tmp.shape[0])
        for x in range(newx,x_max):
            for y in range(newy,y_max):
                rx = x - newx
                ry = y - newy
                if not np.array_equal(tmp[y,x],np.array([0,0,0])) and not np.array_equal(riimg[ry,rx],np.array([0,0,0])):
                    if processwidth==0:
                        alpha = np.minimum(1.0,2.0)
                    else:
                        alpha = np.minimum(rx/processwidth,1.0)
                    tmp[y,x] = alpha*riimg[ry,rx]+(1-alpha)*tmp[y,x]
                elif np.array_equal(tmp[y,x],np.array([0,0,0])):
                    tmp[y,x] = riimg[ry,rx]
                elif np.array_equal(riimg[ry,rx],np.array([0,0,0])):
                    tmp[y,x] = tmp[y,x]
        return tmp

