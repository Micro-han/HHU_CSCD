import cv2
import imutils
from mStitcher import Stitcher

mstitcher = Stitcher()
#初始化 分别读入带拼接的照片名 数量和图片格式
img_dir = './images/'
img_num=int(input())
img_name=input()
img_format=input()
#形成图像列表
images =[]
for i in range(0,img_num):
    imagei = img_dir + str(img_name)+str(i+1)+"."+img_format
    imgi = cv2.imread(imagei)
    #裁剪图像
    r = 500.0/imgi.shape[1]
    dim = (500,int(imgi.shape[0]*r))
    imgi = cv2.resize(imgi , dim, interpolation=cv2.INTER_CUBIC)
    #cv2.imwrite(str(i)+'.png',imgi)
    images.append(imgi)
#用opencv的stl实现
stitcher = cv2.createStitcher() if imutils.is_cv3() else cv2.Stitcher_create()
status, stitched = stitcher.stitch(images)

if status==0:
    #输出第一次拼接的图片
    cv2.imwrite(img_name+'_stitch1_out'+"."+img_format, stitched)
    stitched = mstitcher.Extra(stitched)
    cv2.imwrite(img_name+'_final1_out'+"."+img_format, stitched)

#用自己的类实现
result = mstitcher.stitch(images)
cv2.imwrite(img_name+'_stitch2_out'+"."+img_format, result)
result = mstitcher.Extra(result)
cv2.imwrite(img_name+'_final2_out'+"."+img_format, result)